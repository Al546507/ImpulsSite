const grid = document.getElementById("grid");
if (catalog && grid) {
  catalog.forEach(item => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `<img src="${item.img}" alt="${item.name}"><h3>${item.name}</h3><p>${item.price}</p>`;
    grid.appendChild(div);
  });
}
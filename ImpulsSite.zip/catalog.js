const catalog = [
  {name: "Кирпич керамический", img: "catalog/kirpich.jpg", price: "25 ₽/шт"},
  {name: "Блоки газобетонные", img: "catalog/bloki.jpg", price: "3 500 ₽/м³"},
  {name: "Цемент М500", img: "catalog/cement.jpg", price: "480 ₽/мешок"},
  {name: "Арматура стальная", img: "catalog/armatura.jpg", price: "65 000 ₽/т"},
  {name: "Утеплитель минвата", img: "catalog/uteplitel.jpg", price: "1 200 ₽/упаковка"}
];